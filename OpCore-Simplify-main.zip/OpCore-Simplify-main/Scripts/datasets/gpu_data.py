# Resource: https://en.wikipedia.org/wiki/Graphics_Core_Next
AMDCodenames = [
    "Hainan",
    "Oland",
    "Cape Verde",
    "Pitcairn",
    "Tahiti",
    "Bonaire",
    "Hawaii",
    "Tonga",
    "Fiji"
]